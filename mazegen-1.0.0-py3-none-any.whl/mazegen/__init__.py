"""
Entry point of the mazegen package.

This file exposes the public API of the package: only the classes and
functions listed in __all__ are intended to be imported from outside
(mazegen.app remains an internal implementation detail).
"""

from .config import Config, die
from .generator import MazeGenerator
from .solver import MazeSolver

__all__ = [
    "Config",
    "die",
    "MazeGenerator",
    "MazeSolver",
]
