"""Recherche du plus court chemin par parcours en largeur (BFS)."""

from collections import deque
from typing import Optional

from .constants import DELTA, DIR_NAME
from .generator import MazeGenerator

# Deplacement associe a chaque lettre de direction du fichier de sortie.
_DELTA_MAP: dict[str, tuple[int, int]] = {
    "N": (0, -1), "E": (1, 0), "S": (0, 1), "W": (-1, 0),
}


class MazeSolver:
    """Calcule le plus court chemin entre l'entree et la sortie.

    Le BFS garantit le chemin le plus court car chaque passage entre
    deux cellules coute exactement 1 pas. Le resultat est mis en cache
    apres le premier appel a solve().
    """

    def __init__(self, gen: MazeGenerator) -> None:
        """Attache le solveur a un maze deja genere (ou en cours).

        Args:
            gen: generateur de maze a resoudre.
        """
        self._gen = gen
        self._path: Optional[list[str]] = None
        self._bfs_order: list[tuple[int, int]] = []

    def solve(self) -> list[str]:
        """Trouve le plus court chemin de l'entree vers la sortie.

        Returns:
            Liste de lettres N/E/S/W decrivant le chemin, dans
            l'ordre a suivre depuis l'entree.
        """
        if self._path is not None:
            return self._path

        gen = self._gen
        ex, ey = gen.exit_

        self._bfs_order = [gen.entry]

        queue: deque[tuple[tuple[int, int], list[str]]] = deque(
            [(gen.entry, [])]
        )
        seen: set[tuple[int, int]] = {gen.entry}

        while queue:
            (cx, cy), path = queue.popleft()
            if (cx, cy) == (ex, ey):
                self._path = path
                return path

            for direction, (dx, dy) in DELTA.items():
                nx, ny = cx + dx, cy + dy
                in_bounds = (
                    0 <= nx < gen.width and 0 <= ny < gen.height
                )
                wall_open = not (gen.grid[cy][cx] & direction)
                if in_bounds and (nx, ny) not in seen and wall_open:
                    seen.add((nx, ny))
                    self._bfs_order.append((nx, ny))
                    queue.append(
                        ((nx, ny), path + [DIR_NAME[direction]])
                    )

        self._path = []
        return self._path

    def path_cells(self) -> set[tuple[int, int]]:
        """Retourne l'ensemble des cellules (x, y) situees sur le chemin.

        Returns:
            Un set de coordonnees, y compris l'entree et la sortie.
        """
        cells: set[tuple[int, int]] = {self._gen.entry}
        x, y = self._gen.entry
        for d in self.solve():
            dx, dy = _DELTA_MAP[d]
            x, y = x + dx, y + dy
            cells.add((x, y))
        return cells

    def path_list(self) -> list[tuple[int, int]]:
        """Retourne le chemin comme une liste ordonnee entree -> sortie.

        Utilise pour animer la ligne de resolution dans app.py.

        Returns:
            Liste de coordonnees (x, y), dans l'ordre de parcours.
        """
        result: list[tuple[int, int]] = [self._gen.entry]
        x, y = self._gen.entry
        for d in self.solve():
            dx, dy = _DELTA_MAP[d]
            x, y = x + dx, y + dy
            result.append((x, y))
        return result

    def bfs_order(self) -> list[tuple[int, int]]:
        """Retourne les cellules dans l'ordre de decouverte du BFS.

        Returns:
            Liste de coordonnees, l'entree etant decouverte en premier.
        """
        self.solve()
        return self._bfs_order
