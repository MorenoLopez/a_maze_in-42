"""Fonctions bas niveau : dessin dans le buffer MLX et ecriture du
fichier de sortie."""

from .config import die
from .generator import MazeGenerator


def to_bytes(r: int, g: int, b: int) -> bytes:
    """Convertit une couleur RGB en 4 octets ARGB (format buffer MLX).

    Args:
        r: composante rouge (0-255).
        g: composante verte (0-255).
        b: composante bleue (0-255).

    Returns:
        4 octets au format attendu par le buffer image MLX.
    """
    return (0xFF000000 | (r << 16) | (g << 8) | b).to_bytes(4, "little")


def to_int(r: int, g: int, b: int) -> int:
    """Convertit une couleur RGB en entier 0xAARRGGBB pour mlx_string_put.

    Args:
        r: composante rouge (0-255).
        g: composante verte (0-255).
        b: composante bleue (0-255).

    Returns:
        Entier representant la couleur, au format attendu par MLX.
    """
    return 0xFF000000 | (r << 16) | (g << 8) | b


def fill_rect(
    data: memoryview,
    sl: int,
    x: int,
    y: int,
    w: int,
    h: int,
    cb: bytes,
) -> None:
    """Remplit un rectangle de pixels dans le buffer image.

    Args:
        data: buffer memoire de l'image MLX.
        sl: taille d'une ligne du buffer (size_line).
        x: coordonnee x du coin superieur gauche.
        y: coordonnee y du coin superieur gauche.
        w: largeur du rectangle en pixels.
        h: hauteur du rectangle en pixels.
        cb: couleur a appliquer, au format 4 octets.
    """
    row_bytes = cb * w
    for dy in range(h):
        start = (y + dy) * sl + x * 4
        data[start:start + w * 4] = row_bytes


def draw_hline(
    data: memoryview,
    sl: int,
    x: int,
    y: int,
    length: int,
    thick: int,
    cb: bytes,
) -> None:
    """Dessine une ligne horizontale epaisse dans le buffer.

    Args:
        data: buffer memoire de l'image MLX.
        sl: taille d'une ligne du buffer.
        x: coordonnee x de depart.
        y: coordonnee y de depart.
        length: longueur de la ligne en pixels.
        thick: epaisseur de la ligne en pixels.
        cb: couleur a appliquer.
    """
    fill_rect(data, sl, x, y, length, thick, cb)


def draw_vline(
    data: memoryview,
    sl: int,
    x: int,
    y: int,
    length: int,
    thick: int,
    cb: bytes,
) -> None:
    """Dessine une ligne verticale epaisse dans le buffer.

    Args:
        data: buffer memoire de l'image MLX.
        sl: taille d'une ligne du buffer.
        x: coordonnee x de depart.
        y: coordonnee y de depart.
        length: longueur de la ligne en pixels.
        thick: epaisseur de la ligne en pixels.
        cb: couleur a appliquer.
    """
    fill_rect(data, sl, x, y, thick, length, cb)


def write_output(
    gen: MazeGenerator,
    solution: list[str],
    filepath: str,
) -> None:
    """Ecrit le maze dans le fichier de sortie au format attendu.

    Format : une ligne par rangee (chiffres hexadecimaux), une ligne
    vide, l'entree, la sortie, puis le chemin (lettres N/E/S/W).

    Args:
        gen: generateur contenant le maze a exporter.
        solution: chemin le plus court, sous forme de lettres.
        filepath: chemin du fichier a ecrire.
    """
    try:
        with open(filepath, "w") as f:
            for row in gen.grid:
                f.write(
                    "".join(format(cell, "X") for cell in row) + "\n"
                )
            f.write("\n")
            ex, ey = gen.entry
            xx, xy = gen.exit_
            f.write(f"{ex},{ey}\n")
            f.write(f"{xx},{xy}\n")
            f.write("".join(solution) + "\n")
        print(f"[OK] File written: {filepath!r}")
    except OSError as exc:
        die(f"Unable to write {filepath!r}: {exc}")
