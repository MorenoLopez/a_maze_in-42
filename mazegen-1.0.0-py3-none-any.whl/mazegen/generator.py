"""Generation du maze par backtracking recursif aleatoire."""

import random
import sys
from typing import Optional

from .constants import (
    DELTA,
    EAST,
    OPPOSITE,
    PAT_H,
    PAT_W,
    PATTERN_42,
    SOUTH,
    WEST,
)


class MazeGenerator:
    """Genere un maze en utilisant l'algorithme du backtracker recursif.

    Chaque cellule est un entier 4 bits (voir constants.py) qui indique
    quels murs sont fermes. La generation se fait pas a pas (step) ou
    d'un coup (generate_all), ce qui permet l'animation dans app.py.
    """

    def __init__(
        self,
        width: int,
        height: int,
        entry: tuple[int, int],
        exit_: tuple[int, int],
        seed: Optional[int] = None,
        perfect: bool = True,
    ) -> None:
        """Initialise la grille et demarre la marche depuis l'entree.

        Args:
            width: largeur du maze en cellules.
            height: hauteur du maze en cellules.
            entry: coordonnees (x, y) de l'entree.
            exit_: coordonnees (x, y) de la sortie.
            seed: graine aleatoire, pour reproduire le meme maze.
            perfect: si False, des passages supplementaires seront
                ajoutes a la fin de la generation.
        """
        self.width = width
        self.height = height
        self.entry = entry
        self.exit_ = exit_
        self.perfect = perfect
        self.seed: int = (
            seed if seed is not None else random.randint(0, 999_999)
        )
        random.seed(self.seed)

        # Toutes les cellules commencent avec leurs 4 murs fermes.
        self.grid: list[list[int]] = [
            [0xF] * width for _ in range(height)
        ]
        self.visited: list[list[bool]] = [
            [False] * width for _ in range(height)
        ]
        # Cellules reservees au motif "42", jamais creusees.
        self.is_42: list[list[bool]] = [
            [False] * width for _ in range(height)
        ]

        self.current: Optional[tuple[int, int]] = None
        self.done: bool = False
        self.pattern_skipped: bool = False
        self._stack: list[tuple[int, int]] = []

        self._stamp_42()
        self._start_walk()

    def _stamp_42(self) -> None:
        """Reserve les cellules du motif "42" au centre du maze.

        Si le maze est trop petit pour contenir le motif, un message
        est affiche sur la console et le motif est ignore.
        """
        if self.width < PAT_W + 4 or self.height < PAT_H + 4:
            print(
                "[Info] Maze too small for pattern '42' "
                f"(minimum {PAT_W + 4}x{PAT_H + 4}, "
                f"current {self.width}x{self.height}).",
                file=sys.stderr,
            )
            self.pattern_skipped = True
            return

        ox = (self.width - PAT_W) // 2
        oy = (self.height - PAT_H) // 2

        for r in range(PAT_H):
            for c in range(PAT_W):
                if PATTERN_42[r][c] == 1:
                    gx, gy = ox + c, oy + r
                    self.visited[gy][gx] = True
                    self.is_42[gy][gx] = True

    def _start_walk(self) -> None:
        """Marque l'entree comme visitee et initialise la pile."""
        sx, sy = self.entry
        self.visited[sy][sx] = True
        self._stack = [(sx, sy)]
        self.current = (sx, sy)

    def step(self, n: int = 1) -> None:
        """Avance la generation de n etapes du backtracker.

        A chaque etape, on essaie d'avancer vers un voisin non visite
        dans une direction aleatoire. Si aucun voisin n'est
        disponible, on recule dans la pile (backtrack).

        Args:
            n: nombre d'etapes a executer.
        """
        for _ in range(n):
            if not self._stack:
                self._finish()
                return

            x, y = self._stack[-1]
            self.current = (x, y)

            dirs = list(DELTA.keys())
            random.shuffle(dirs)
            moved = False

            for direction in dirs:
                dx, dy = DELTA[direction]
                nx, ny = x + dx, y + dy
                in_bounds = (
                    0 <= nx < self.width and 0 <= ny < self.height
                )
                if in_bounds and not self.visited[ny][nx]:
                    # On perce le mur des deux cotes en meme temps
                    # pour garder les cellules voisines coherentes.
                    self.grid[y][x] &= ~direction
                    self.grid[ny][nx] &= ~OPPOSITE[direction]
                    self.visited[ny][nx] = True
                    self._stack.append((nx, ny))
                    moved = True
                    break

            if not moved:
                self._stack.pop()

        if not self._stack:
            self._finish()

    def generate_all(self) -> None:
        """Genere le maze complet en une seule fois (sans animation)."""
        while not self.done:
            self.step(256)

    def _finish(self) -> None:
        """Marque la generation comme terminee.

        Si le maze ne doit pas etre parfait, des passages
        supplementaires sont ajoutes ensuite.
        """
        self.done = True
        self.current = None
        if not self.perfect:
            self._add_loops()

    def _add_loops(self) -> None:
        """Perce des passages supplementaires pour un maze imparfait.

        Chaque passage candidat est verifie avant d'etre perce, pour
        ne jamais creer de zone entierement ouverte de 3x3 cellules ou
        plus (interdit par le sujet).
        """
        extra = max(1, (self.width * self.height) // 10)
        max_attempts = extra * 20
        added = 0
        attempts = 0

        while added < extra and attempts < max_attempts:
            attempts += 1
            x = random.randint(0, self.width - 2)
            y = random.randint(0, self.height - 2)

            if self.is_42[y][x] or self.is_42[y][x + 1]:
                continue
            if not (self.grid[y][x] & EAST):
                continue
            if self._would_create_large_opening(x, y):
                continue

            self.grid[y][x] &= ~EAST
            self.grid[y][x + 1] &= ~WEST
            added += 1

    def _would_create_large_opening(self, x: int, y: int) -> bool:
        """Verifie si percer le mur Est de (x, y) creerait un bloc
        2x2 entierement ouvert (donc une zone 3x3+ en pratique).

        Args:
            x: colonne de la cellule dont on veut percer le mur Est.
            y: ligne de la cellule.

        Returns:
            True si la perforation est dangereuse et doit etre evitee.
        """
        y_min = max(0, y - 1)
        y_max = min(self.height - 2, y + 1)
        x_min = max(0, x - 1)
        x_max = min(self.width - 2, x)

        for oy in range(y_min, y_max + 1):
            for ox in range(x_min, x_max + 1):
                if self._block_is_open(ox, oy, ox == x and oy == y):
                    return True
        return False

    def _block_is_open(
        self,
        x: int,
        y: int,
        simulate_east: bool,
    ) -> bool:
        """Teste si le bloc 2x2 partant de (x, y) est deja ouvert.

        Args:
            x: colonne du coin superieur gauche du bloc 2x2.
            y: ligne du coin superieur gauche du bloc 2x2.
            simulate_east: si True, simule le mur Est de (x, y) deja
                perce (utilise pour tester avant de creuser).

        Returns:
            True si les 4 murs internes du bloc sont deja ouverts.
        """
        east_top = simulate_east or not (self.grid[y][x] & EAST)
        east_bottom = not (self.grid[y + 1][x] & EAST)
        south_left = not (self.grid[y][x] & SOUTH)
        south_right = not (self.grid[y][x + 1] & SOUTH)
        return east_top and east_bottom and south_left and south_right
